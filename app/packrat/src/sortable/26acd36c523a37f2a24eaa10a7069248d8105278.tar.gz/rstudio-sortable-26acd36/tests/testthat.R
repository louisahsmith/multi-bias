library(testthat)
library(sortable)

test_check("sortable")
