## Response to CRAN review

In reponse to the 2nd CRAN review, I edited the description to not start with "the sortable package..."

## Test environments

* local Windows install, R 3.6.1
* ubuntu 14.04 (on travis-ci), R-release, R-dev and R-old-release
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.
