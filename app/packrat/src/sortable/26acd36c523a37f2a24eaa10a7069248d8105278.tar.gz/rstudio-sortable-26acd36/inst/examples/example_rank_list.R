## - example-rank-list ------------------------------------------------

rank_list(
  text = "You can drag, drap and re-order these items:",
  labels = c("one", "two", "three", "four", "five"),
  input_id = "example_2"
)
