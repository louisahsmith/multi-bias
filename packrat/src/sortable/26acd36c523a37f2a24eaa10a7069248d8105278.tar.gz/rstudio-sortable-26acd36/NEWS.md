# sortable (development version)

# sortable 0.4.2 (Release date 2019-11-28)

* First release accepted by CRAN


# sortable 0.4.0 (Release date 2019-11-10)

* First candidate release to CRAN
